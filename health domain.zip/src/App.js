import React from 'react';
import HealthDashboard from './HealthDashboard';

function App() {
  return (
    <HealthDashboard></HealthDashboard>
  );
}

export default App;
